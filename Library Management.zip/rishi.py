
from tkinter import*
from tkinter import ttk
import tkinter
from tkinter import messagebox
import datetime
import mysql.connector 




class librarymanagementsystem:
        def __init__(self,root):
                self.root=root
                self.root.title("COLLEGE LIBRARY SYSTEM")
                self.root.geometry("1550x800+0+0")



# ====================================variable==================================================

                self.member_var=StringVar()
                self.prn_var=StringVar()
                self.id_var=StringVar()
                self.firstname_var=StringVar()
                self.lastname_var=StringVar()
                self.address1_var=StringVar()
                self.address2_var=StringVar()
                self.postcode_var=StringVar()
                self.mobile_var=StringVar()
                self.bookid_var=StringVar()
                self.booktitle_var=StringVar()
                self.auther_var=StringVar()
                self.dateborrowed_var=StringVar()
                self.datedue_var=StringVar()
                self.daysonbook_var=StringVar()
                self.lateratefine_var=StringVar()
                self.dateoverdue_var=StringVar()
                self.finallprice_var=StringVar()




                lbltitle=Label(self.root,text="LIBRARY MANAGMENT SYSTEM",bg="powder blue",fg="green",bd=20,relief=RIDGE,font=("times new roman",50,"bold"),padx=2,pady=6)
                lbltitle.pack(side=TOP,fill=X)
                
                frame=Frame(self.root,bd=12,relief=RIDGE,pady=20,bg="powder blue")
                frame.place(x=0,y=130,width=1530,height=400)

                # =================================DataFrameLeft====================================================

                DataFrameleft=LabelFrame(frame,text="Library membership informetion",bg="powder blue",fg="green",bd=12,relief=RIDGE,font=("times new roman",12,"bold"))
                DataFrameleft.place(x=0,y=5,width=900,height=350)

                lblmemebr=Label(DataFrameleft,bg="powder blue",text="Member Type",font=("Arial",12,"bold"),padx=2,pady=6)
                lblmemebr.grid(row=0,column=0,sticky=W)

                Commember=ttk.Combobox(DataFrameleft,font=("Arial",12,"bold"),width=27,state="readonly",textvariable=self.member_var)
                Commember["value"]=("Admin staf","Student","Lecturer")
                Commember.grid(row=0,column=1)



                lblPRN_NO=Label(DataFrameleft,bg="powder blue",text="PRN NO:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblPRN_NO.grid(row=1,column=0,sticky=W)
                txtPRN_NO=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.prn_var)
                txtPRN_NO.grid(row=1,column=1)



                lbltitle=Label(DataFrameleft,bg="powder blue",text="ID NO:",font=("Arial",12,"bold"),padx=2,pady=4)
                lbltitle.grid(row=2,column=0,sticky=W)
                txttitle=Entry(DataFrameleft,font=("Arial",13,"bold"),width=29,textvariable=self.id_var)
                txttitle.grid(row=2,column=1)


                lblFirstName=Label(DataFrameleft,bg="powder blue",text="FirstName:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblFirstName.grid(row=3,column=0,sticky=W)
                txtFirstName=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.firstname_var)
                txtFirstName.grid(row=3,column=1)



                lbllastnane=Label(DataFrameleft,bg="powder blue",text="LastName:",font=("Arial",12,"bold"),padx=2,pady=4)
                lbllastnane.grid(row=4,column=0,sticky=W)
                txtlastname=Entry(DataFrameleft,font=("Arial",13,"bold"),width=29,textvariable=self.lastname_var)
                txtlastname.grid(row=4,column=1)


                lblAddress1=Label(DataFrameleft,bg="powder blue",text="Address1:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblAddress1.grid(row=5,column=0,sticky=W)
                txtaddress1=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.address1_var)
                txtaddress1.grid(row=5,column=1)



                lblAddress2=Label(DataFrameleft,bg="powder blue",text="Address2:",font=("Arial",12,"bold"),padx=2,pady=4)
                lblAddress2.grid(row=6,column=0,sticky=W)
                txtaddress2=Entry(DataFrameleft,font=("Arial",13,"bold"),width=29,textvariable=self.address2_var)
                txtaddress2.grid(row=6,column=1)


                lblpostcode=Label(DataFrameleft,bg="powder blue",text="Post code:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblpostcode.grid(row=7,column=0,sticky=W)
                txtpostcode=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.postcode_var)
                txtpostcode.grid(row=7,column=1)



                lblmobile=Label(DataFrameleft,bg="powder blue",text="Mobile NO:",font=("Arial",12,"bold"),padx=2,pady=4)
                lblmobile.grid(row=8,column=0,sticky=W)
                txtmobile=Entry(DataFrameleft,font=("Arial",13,"bold"),width=29,textvariable=self.mobile_var)
                txtmobile.grid(row=8,column=1)


                lblbookid=Label(DataFrameleft,bg="powder blue",text="Book Id:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblbookid.grid(row=0,column=2,sticky=W)
                txtbookid=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.bookid_var)
                txtbookid.grid(row=0,column=3)



                lblbooktitle=Label(DataFrameleft,bg="powder blue",text="Book Title:",font=("Arial",12,"bold"),padx=2,pady=4)
                lblbooktitle.grid(row=1,column=2,sticky=W)
                txtbooktitle=Entry(DataFrameleft,font=("Arial",13,"bold"),width=29,textvariable=self.booktitle_var)
                txtbooktitle.grid(row=1,column=3)


                lblAuther=Label(DataFrameleft,bg="powder blue",text="Auther Name:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblAuther.grid(row=2,column=2,sticky=W)
                txtAuther=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.auther_var)
                txtAuther.grid(row=2,column=3)



                lblDateBorrowed=Label(DataFrameleft,bg="powder blue",text="DateBorrowed:",font=("Arial",12,"bold"),padx=2,pady=4)
                lblDateBorrowed.grid(row=3,column=2,sticky=W)
                txtDateBorrowed=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.dateborrowed_var)
                txtDateBorrowed.grid(row=3,column=3)


                lblDateDue=Label(DataFrameleft,bg="powder blue",text="Date Due:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblDateDue.grid(row=4,column=2,sticky=W)
                txtDateDue=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.datedue_var)
                txtDateDue.grid(row=4,column=3)



                lbldaysonbook=Label(DataFrameleft,bg="powder blue",text="Days On Book:",font=("Arial",12,"bold"),padx=2,pady=4)
                lbldaysonbook.grid(row=5,column=2,sticky=W)
                txtdaysonbook=Entry(DataFrameleft,font=("Arial",13,"bold"),width=29,textvariable=self.daysonbook_var)
                txtdaysonbook.grid(row=5,column=3)


                lblLateReturnFine=Label(DataFrameleft,bg="powder blue",text="Late Return Fine:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblLateReturnFine.grid(row=6,column=2,sticky=W)
                txtLateReturnFine=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.lateratefine_var)
                txtLateReturnFine.grid(row=6,column=3)



                lblDateoverDate=Label(DataFrameleft,bg="powder blue",text="Date Over Date:",font=("Arial",12,"bold"),padx=2,pady=4)
                lblDateoverDate.grid(row=7,column=2,sticky=W)
                txtDateoverDate=Entry(DataFrameleft,font=("Arial",13,"bold"),width=29,textvariable=self.dateoverdue_var)
                txtDateoverDate.grid(row=7,column=3)


                lblActualPrise=Label(DataFrameleft,bg="powder blue",text="Actual Prise:",font=("Arial",12,"bold"),padx=2,pady=6)
                lblActualPrise.grid(row=8,column=2,sticky=W)
                txtActualPrise=Entry(DataFrameleft,font=("Arial",12,"bold"),width=29,textvariable=self.finallprice_var)
                txtActualPrise.grid(row=8,column=3)

                # ================================Data Frame Right==================================================


                DataFrameRight=LabelFrame(frame,text="Book Details",bg="powder blue",fg="green",bd=12,relief=RIDGE,font=("times new roman",12,"bold"))
                DataFrameRight.place(x=910,y=5,width=540,height=350)


                self.txtBox=Text(DataFrameRight,font=("Arial",12,"bold"),width=32,height=16,padx=2,pady=6)
                self.txtBox.grid(row=0,column=2)

                listscrollbar=Scrollbar( DataFrameRight)
                listscrollbar.grid(row=0,column=1,sticky=NS)


                listbooks=['Head Firt Book','Learn Python The Hard Way','python programming','Secret Rahshy','Python Book','Into The Machine Learing','Fluent Python','Machine tecno','My Python','Joss Ellif Guru','Jungli Python','Elite Jungle Python',
                                                                                                                                                                         'Machine Python','Advance Python','Intro Python','RedChilli Python','Basic Python']
                
                def selectbook(event=""):
                        value=str(listBox.get(listBox.curselection()))
                        x=value

                        if (x=="Head Firt Book"):
                                self.bookid_var.set("BSID5454")
                                self.booktitle_var.set("Python Manual")
                                self.auther_var.set("Pual Berry")

                                d1=datetime.datetime.today()
                                d2=datetime.timedelta(days=15)
                                d3=d1+d2
                                self.dateborrowed_var.set(d1)
                                self.datedue_var.set(d3)
                                self.daysonbook_var.set(15)
                                self.lateratefine_var.set("Rs.50")
                                self.dateoverdue_var.set("No")
                                self.finallprice_var.set("Rs.799")

                        elif (x=="Learn Python The Hard Way"):
                                self.bookid_var.set("POIHW6598")
                                self.booktitle_var.set("Basic of python")
                                self.auther_var.set("ZED A.SHAW")

                                d1=datetime.datetime.today()
                                d2=datetime.timedelta(days=15)
                                d3=d1+d2
                                self.dateborrowed_var.set(d1)
                                self.datedue_var.set(d3)
                                self.daysonbook_var.set(15)
                                self.lateratefine_var.set("Rs.20")
                                self.dateoverdue_var.set("No")
                                self.finallprice_var.set("Rs.685")


                        elif (x=="python programming"):
                                self.bookid_var.set("LOURV5454")
                                self.booktitle_var.set(" BASIC CONCEPT OF PYTHON ")
                                self.auther_var.set("JINOE L.RAO")
                                d1=datetime.datetime.today()
                                d2=datetime.timedelta(days=15)
                                d3=d1+d2
                                self.dateborrowed_var.set(d1)
                                self.datedue_var.set(d3)
                                self.daysonbook_var.set(15)
                                self.lateratefine_var.set("Rs.40")
                                self.dateoverdue_var.set("No")
                                self.finallprice_var.set("Rs.579")

        
                        elif (x=="Secret Rahshy"):
                                self.bookid_var.set("JGFD5454")
                                self.booktitle_var.set("ADVANCE PYTHON")
                                self.auther_var.set("ZENUE J.SAM")
                                d1=datetime.datetime.today()
                                d2=datetime.timedelta(days=15)
                                d3=d1+d2
                                self.dateborrowed_var.set(d1)
                                self.datedue_var.set(d3)
                                self.daysonbook_var.set(15)
                                self.lateratefine_var.set("Rs.100")
                                self.dateoverdue_var.set("No")
                                self.finallprice_var.set("Rs.989")

                        
                        elif (x=="Python Book"):
                                self.bookid_var.set("UYTI5118")
                                self.booktitle_var.set("CORE OF PYTHON")
                                self.auther_var.set("SEB P.SHAW")

                                d1=datetime.datetime.today()
                                d2=datetime.timedelta(days=15)
                                d3=d1+d2
                                self.dateborrowed_var.set(d1)
                                self.datedue_var.set(d3)
                                self.daysonbook_var.set(15)
                                self.lateratefine_var.set("Rs.80")
                                self.dateoverdue_var.set("No")
                                self.finallprice_var.set("Rs.855")


                        elif (x=="Into The Machine Learing"):
                                self.bookid_var.set("IMLV5454")
                                self.booktitle_var.set(" BASIC OF MACINE LEARNING ")
                                self.auther_var.set("KIVO L.RAO")
                                d1=datetime.datetime.today()
                                d2=datetime.timedelta(days=15)
                                d3=d1+d2
                                self.dateborrowed_var.set(d1)
                                self.datedue_var.set(d3)
                                self.daysonbook_var.set(15)
                                self.lateratefine_var.set("Rs.60")
                                self.dateoverdue_var.set("No")
                                self.finallprice_var.set("Rs.979")

        
                        elif (x=="Fluent Python"):
                                self.bookid_var.set("FLUNT9635")
                                self.booktitle_var.set(" BASIC AND ADVANCE PYTHON")
                                self.auther_var.set("JONOUS J.KORU")
                                d1=datetime.datetime.today()
                                d2=datetime.timedelta(days=15)
                                d3=d1+d2
                                self.dateborrowed_var.set(d1)
                                self.datedue_var.set(d3)
                                self.daysonbook_var.set(15)
                                self.lateratefine_var.set("Rs.105")
                                self.dateoverdue_var.set("No")
                                self.finallprice_var.set("Rs.1119")

                
                
                listBox=Listbox(DataFrameRight,font=("Arial",12,"bold"),width=20,height=16)
                listBox.bind("<<ListboxSelect>>",selectbook)
                listBox.grid(row=0,column=0,padx=4)
                listscrollbar.config(command=listBox.yview)

                for item in listbooks:
                        listBox.insert(END,item)


                #====================================BUTTONS FRAME=============================================================

                Framebutton=Frame(self.root,bd=12,relief=RIDGE,padx=20,bg="powder blue")
                Framebutton.place(x=0,y=530,width=1530,height=70)

                btnAddData=Button(Framebutton,command=self.add_data,text="Add Data",font=("Arial",12,"bold"),width=20,bg="blue",fg="white")
                btnAddData.grid(row=0,column=0)

                btnAddData=Button(Framebutton,command=self.showdata,text="Show Data",font=("Arial",12,"bold"),width=20,bg="blue",fg="white")
                btnAddData.grid(row=0,column=1)

                btnAddData=Button(Framebutton,command=self.update,text="Update",font=("Arial",12,"bold"),width=20,bg="blue",fg="white")
                btnAddData.grid(row=0,column=2)

                btnAddData=Button(Framebutton,command=self.Delete,text="Delete",font=("Arial",12,"bold"),width=20,bg="blue",fg="white")
                btnAddData.grid(row=0,column=3)

                btnAddData=Button(Framebutton,command=self.reset,text="Reset",font=("Arial",12,"bold"),width=20,bg="blue",fg="white")
                btnAddData.grid(row=0,column=4)

                btnAddData=Button(Framebutton,command=self.iExit,text="Exit",font=("Arial",12,"bold"),width=20,bg="blue",fg="white")
                btnAddData.grid(row=0,column=5)

                btnAddData=Button(Framebutton,text="Add book image",font=("Arial",12,"bold"),width=20,bg="blue",fg="white")
                btnAddData.grid(row=0,column=6)





                #====================================INFORMETION FRAME=============================================================
                
                FrameDetail=Frame(self.root,bd=12,relief=RIDGE,padx=20,bg="powder blue")
                FrameDetail.place(x=0,y=600,width=1530,height=195)

                Table_frame=Frame(FrameDetail,bd=6,relief=RIDGE,padx=20,bg="powder blue")
                Table_frame.place(x=0,y=2,width=1460,height=195)

                xcroll=ttk.Scrollbar( Table_frame,orient=HORIZONTAL) 
                ycroll=ttk.Scrollbar( Table_frame,orient=VERTICAL)               
                self.libray_table=ttk.Treeview(Table_frame,column=("membertype","prnno","title","firstname","lastname",
                                                                "address1","address2","postid","mobile","bookid","booktitle","auther","dateborrowed",
                                                                "datedue","days","laterelturnfile","dateoverdue","finalprice"),xscrollcommand= xcroll.set,yscrollcommand= ycroll.set)

                xcroll.pack(side=BOTTOM,fill=X)
                ycroll.pack(side=RIGHT,fill=Y)

                xcroll.config(command=self.libray_table.xview)
                ycroll.config(command=self.libray_table.yview)


                self.libray_table.heading("membertype",text="Member Type")
                self.libray_table.heading("prnno",text="PRN No.")
                self.libray_table.heading("title",text="Title")
                self.libray_table.heading("firstname",text="First Name")
                self.libray_table.heading("lastname",text="Last Name")
                self.libray_table.heading("address1",text="Address1")
                self.libray_table.heading("address2",text="Address2")
                self.libray_table.heading("postid",text="Post ID")
                self.libray_table.heading("mobile",text="Mobile No")
                self.libray_table.heading("bookid",text="Book ID")
                self.libray_table.heading("booktitle",text="Book Title")
                self.libray_table.heading("auther",text="Auther")
                self.libray_table.heading("dateborrowed",text="Data of Borrowed")
                self.libray_table.heading("datedue",text="Date Due")
                self.libray_table.heading("days",text="Days On Book")
                self.libray_table.heading("laterelturnfile",text="Late Return Fine")
                self.libray_table.heading("dateoverdue",text="Date Over Due")
                self.libray_table.heading("finalprice",text="Final Prise")

                self.libray_table["show"]="headings"
                self.libray_table.pack(fill=BOTH,expand=1)


                self.libray_table.column("membertype",width=100)
                self.libray_table.column("prnno",width=100)
                self.libray_table.column("title",width=100)
                self.libray_table.column("firstname",width=100)
                self.libray_table.column("lastname",width=100)
                self.libray_table.column("address1",width=100)
                self.libray_table.column("address2",width=100)
                self.libray_table.column("postid",width=100)
                self.libray_table.column("mobile",width=100)
                self.libray_table.column("bookid",width=100)
                self.libray_table.column("booktitle",width=100)
                self.libray_table.column("auther",width=100)
                self.libray_table.column("dateborrowed",width=100)
                self.libray_table.column("datedue",width=100)
                self.libray_table.column("days",width=100)
                self.libray_table.column("laterelturnfile",width=100)
                self.libray_table.column("dateoverdue",width=100)
                self.libray_table.column("finalprice",width=100)

                self.fatch_data()
                self.libray_table.bind("<ButtonRelease-1>",self.get_cursor)




        def add_data(self):
                conn=mysql.connector.connect(host="localhost",username="root",password="Abhishek#123",database="mydata")
                my_cursor=conn.cursor()         
                my_cursor.execute("insert into library values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(
                                                                                                       self.member_var.get(),
                                                                                                       self.prn_var.get(),
                                                                                                       self.id_var.get(),
                                                                                                       self.firstname_var.get(),
                                                                                                       self.lastname_var.get(),
                                                                                                       self.address1_var.get(),
                                                                                                       self.address2_var.get(),
                                                                                                       self.postcode_var.get(),
                                                                                                       self.mobile_var.get(),
                                                                                                       self.bookid_var.get(),
                                                                                                       self.booktitle_var.get(),
                                                                                                       self.auther_var.get(),
                                                                                                       self.dateborrowed_var.get(),
                                                                                                       self.datedue_var.get(),
                                                                                                       self.daysonbook_var.get(),
                                                                                                       self.lateratefine_var.get(),
                                                                                                       self.dateoverdue_var.get(),
                                                                                                       self.finallprice_var.get() ))
                conn.commit()
                self.fatch_data()
                conn.close()

                messagebox.showinfo("success","Member Has Been Added Successfully") 



        def update(self):
                conn=mysql.connector.connect(host="localhost",username="root",password="Abhishek#123",database="mydata")
                my_cursor=conn.cursor()
                my_cursor.execute("update library set Member=%s,ID=%s,FirstName=%s,LastName=%s,Address1=%s,Address2=%s,Post code=%s,Mobile=%s,Book Id=%s,Book Title=%s,Auther=%s,Dateborrowed=%s,Date due=%s,Days of book=%s,Latral Final fine=%s,Date over due=%s,Finnal price=%s where PRN_NO=%s",
                                                                                                                                                                                                                                        (self.member_var.get(),  
                                                                                                                                                                                                                                        self.id_var.get(),
                                                                                                                                                                                                                                        self.firstname_var.get(),
                                                                                                                                                                                                                                        self.lastname_var.get(),
                                                                                                                                                                                                                                        self.address1_var.get(),
                                                                                                                                                                                                                                        self.address2_var.get(),
                                                                                                                                                                                                                                        self.postcode_var.get(),
                                                                                                                                                                                                                                        self.mobile_var.get(),
                                                                                                                                                                                                                                        self.bookid_var.get(),
                                                                                                                                                                                                                                        self.booktitle_var.get(),
                                                                                                                                                                                                                                        self.auther_var.get(),
                                                                                                                                                                                                                                        self.dateborrowed_var.get(),
                                                                                                                                                                                                                                        self.datedue_var.get(),
                                                                                                                                                                                                                                        self.daysonbook_var.get(),
                                                                                                                                                                                                                                        self.lateratefine_var.get(),
                                                                                                                                                                                                                                        self.dateoverdue_var.get(),
                                                                                                                                                                                                                                        self.finallprice_var.get(),
                                                                                                                                                                                                                                        self.prn_var.get()))
                conn.commit()
                self.fatch_data()
                self.reset()
                conn.close()   

                messagebox.showinfo("Success","Member has been updated")                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                        




                

        def fatch_data(self):
                conn=mysql.connector.connect(host="localhost",username="root",password="Abhishek#123",database="mydata")
                my_cursor=conn.cursor()
                my_cursor.execute("select * from library")
                rows=my_cursor.fetchall()

                if len(rows)!=0:
                        self.libray_table.delete(*self.libray_table.get_children())
                        for i in rows:
                                self.libray_table.insert("",END,values=i)
                        conn.commit()
                conn.close()
        




        def get_cursor(self,event=""):
                Cursor_row=self.libray_table.focus()
                content=self.libray_table.item(Cursor_row)
                row=content['values']

                self.member_var.set(row[0]),
                self.prn_var.set(row[1]),
                self.id_var.set(row[2]),
                self.firstname_var.set(row[3]),
                self.lastname_var.set(row[4]),
                self.address1_var.set(row[5]),
                self.address2_var.set(row[6]),
                self.postcode_var.set(row[7]),
                self.mobile_var.set(row[8]),
                self.bookid_var.set(row[9]),
                self.booktitle_var.set(row[10]),
                self.auther_var.set(row[11]),
                self.dateborrowed_var.set([12]),
                self.datedue_var.set(row[13]),
                self.daysonbook_var.set(row[14]),
                self.lateratefine_var.set(row[15]),
                self.dateoverdue_var.set(row[16]),
                self.finallprice_var.set(row[17])


        def showdata(self):
                self.txtBox.insert(END,"Member Type :\t\t"+self.member_var.get() + "\n")
                self.txtBox.insert(END,"PNR NO. :\t\t"+self.prn_var.get() + "\n")
                self.txtBox.insert(END,"ID NO. :\t\t"+self.id_var.get() + "\n")
                self.txtBox.insert(END,"First Name :\t\t"+self.firstname_var.get() + "\n")
                self.txtBox.insert(END,"Last Name :\t\t"+self.lastname_var.get() + "\n")
                self.txtBox.insert(END,"Address 1 :\t\t"+self.address1_var.get() + "\n")
                self.txtBox.insert(END,"Address 2 :\t\t"+self.address2_var.get() + "\n")
                self.txtBox.insert(END,"Post code :\t\t"+self.mobile_var.get() + "\n")
                self.txtBox.insert(END,"Mobile no. :\t\t"+self.mobile_var.get() + "\n")
                self.txtBox.insert(END,"Book ID :\t\t"+self.bookid_var.get() + "\n")
                self.txtBox.insert(END,"Book title :\t\t"+self.booktitle_var.get() + "\n")
                self.txtBox.insert(END,"Auther :\t\t"+self.auther_var.get() + "\n")
                self.txtBox.insert(END,"Date Borrowed :\t\t"+self.dateborrowed_var.get() + "\n")
                self.txtBox.insert(END,"Date Due :\t\t"+self.datedue_var.get() + "\n")
                self.txtBox.insert(END,"Days On Book :\t\t"+self.daysonbook_var.get() + "\n")
                self.txtBox.insert(END,"Latral Fine :\t\t"+self.lateratefine_var.get() + "\n")
                self.txtBox.insert(END,"Date Over Due :\t\t"+self.datedue_var.get() + "\n")
                self.txtBox.insert(END,"Finall Price :\t\t"+self.finallprice_var.get() + "\n")



        def reset(self):
                self.member_var.set(""),
                self.prn_var.set(""),
                self.id_var.set(""),
                self.firstname_var.set(""),
                self.lastname_var.set(""),
                self.address1_var.set(""),
                self.address2_var.set(""),
                self.postcode_var.set(""),
                self.mobile_var.set(""),
                self.bookid_var.set(""),
                self.booktitle_var.set(""),
                self.auther_var.set(""),
                self.dateborrowed_var.set(""),
                self.datedue_var.set(""),
                self.daysonbook_var.set(""),
                self.lateratefine_var.set(""),
                self.dateoverdue_var.set(""),
                self.finallprice_var.set("")
                self.txtBox.delete("1.0",END)


        def iExit(self):
                iExit= tkinter.Messagebox.askyesno ("Library Manegement System","Do you want to exit")
                if iExit >0:
                        self.root.destroy()
                return


        def Delete(self):

                if self.prn_var.get()=="" or self.id_var.get()=="" :

                        messagebox.showerror("Error", "First Select the Member")
                else:
                        conn=mysql.connector.connect(host="localhost",username="root",password="Abhishek#123",database="mydata")
                        my_cursor=conn.cursor()
                        query="delete from library where PRN_No=%s"
                        Value=(self.prn_var.get(),)
                        my_cursor.execute(query,Value)

                        conn.commit()
                        self.fatch_data()
                        self.reset()
                        conn.close()

                        messagebox.showinfo("Success","Member has been Deleted ")


if __name__ == "__main__":
    root=Tk()
    obj=librarymanagementsystem(root)
    root.mainloop()
